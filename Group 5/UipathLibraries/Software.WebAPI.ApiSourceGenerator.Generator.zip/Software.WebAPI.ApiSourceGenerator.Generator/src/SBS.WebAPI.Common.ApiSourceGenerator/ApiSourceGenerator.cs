﻿namespace SBS.WebAPI.Common.ApiSourceGenerator;

using Microsoft.CodeAnalysis;
using Newtonsoft.Json;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;
using System.Collections.Generic;
using System.Linq;

public class ApiSourceGenerator
{
    // https://github.com/JoanComasFdz/dotnet-how-to-debug-source-generator-vs2022
    [Generator]
    public class OpenApiGenerator : IIncrementalGenerator
    {
        public void Initialize(IncrementalGeneratorInitializationContext initContext)
        {
            GenerateCanary(initContext);
            GenerateOpenApiYamls(initContext);
        }

        private void GenerateCanary(IncrementalGeneratorInitializationContext initContext)
        {
            IncrementalValuesProvider<AdditionalText> textFiles = initContext.AdditionalTextsProvider.Where(static file => file.Path.EndsWith("Canary.txt"));
            IncrementalValuesProvider<(string name, string content)> namesAndContents = textFiles.Select((text, cancellationToken) => (name: Path.GetFileNameWithoutExtension(text.Path), content: text.GetText(cancellationToken)!.ToString()));
            initContext.RegisterSourceOutput(namesAndContents, (spc, nameAndContent) =>
            {
                spc.AddSource($"ConstStrings.{nameAndContent.name}.g.cs", $@"
    public static partial class ConstStrings
    {{
        public const string {nameAndContent.name} = ""{nameAndContent.content}"";
    }}");
            });
        }

        private List<ContractSettings> GetContractSettings(IncrementalGeneratorInitializationContext initContext)
        {
            IncrementalValuesProvider<AdditionalText> settingsFiles = initContext.AdditionalTextsProvider.Where(static file => file.Path.Contains("contractSettings"));
            IncrementalValuesProvider<(string name, string content)> namesAndContents = settingsFiles.Select((text, cancellationToken) => (name: Path.GetFileNameWithoutExtension(text.Path), content: text.GetText(cancellationToken)!.ToString()));

            var settings = new List<ContractSettings>();

            initContext.RegisterSourceOutput(namesAndContents, (spc, nameAndContent) =>
            {
                var values = GetContractSettingsContent(nameAndContent);

                foreach (var item in values)
                {
                    settings.Add(item);
                }
            });

            return settings;
        }

        private static List<ContractSettings> GetContractSettingsContent((string name, string content) nameAndContent)
        {
            try
            {
                return JsonConvert.DeserializeObject<List<ContractSettings>>(nameAndContent.content)!;
            }
            catch (Exception exception)
            {
                throw new JsonException($"Failed to deserialize {nameAndContent.content} to contract settings", exception);
            }
        }

        private void GenerateOpenApiYamls(IncrementalGeneratorInitializationContext initContext)
        {
            var contractSettings = GetContractSettings(initContext);

            IncrementalValuesProvider<AdditionalText> textFiles = initContext.AdditionalTextsProvider.Where(file => file.Path.EndsWith(".yaml"));
            IncrementalValuesProvider<(string name, string content)> namesAndContents = textFiles.Select((text, cancellationToken) => (name: Path.GetFileNameWithoutExtension(text.Path), content: text.GetText(cancellationToken)!.ToString()));

            // Generate a class that contains their values as const strings
            initContext.RegisterSourceOutput(namesAndContents, (spc, nameAndContent) =>
            {
                var contractSettingsNames = contractSettings.Select(c => c.ContractName).ToArray();

                OpenApiSourceFactory openApiGenerator = new(nameAndContent.content);
                var matchingContractSettings = contractSettings.SingleOrDefault(x => x.ContractName == nameAndContent.name);

                if (matchingContractSettings != null)
                {
                    GenerateModels(spc, openApiGenerator, matchingContractSettings);
                    GenerateEnums(spc, openApiGenerator, matchingContractSettings);
                    GenerateResponseClasses(spc, openApiGenerator, matchingContractSettings);
                    GenerateBehaviourInterfaces(spc, openApiGenerator, matchingContractSettings);
                    GenerateControllers(spc, openApiGenerator, matchingContractSettings);
                    GenerateClientTypes(spc, openApiGenerator, matchingContractSettings);
                    GenerateHelperClass(spc, matchingContractSettings);
                }
            });
        }

        private static void GenerateModels(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.Models)
            {
                return;
            }

            IList<OpenApiModelClass> modelClasses = openApiGenerator.GenerateModels(matchingContractSettings);
            foreach (var modelClass in modelClasses)
            {
                spc.AddSource($"{modelClass.ServiceNamespace}_Models_{modelClass.ClassName}.g.cs", modelClass.RenderSource());
            }
        }

        private static void GenerateEnums(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.Models)
            {
                return;
            }

            IList<OpenApiEnum> enums = openApiGenerator.GenerateEnums();
            foreach (var @enum in enums)
            {
                spc.AddSource($"{@enum.ServiceNamespace}_Enums_{@enum.EnumName}.g.cs", @enum.RenderSource());
            }
        }

        private static void GenerateResponseClasses(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.ResponseClasses)
            {
                return;
            }

            IList<OpenApiModelClass> responseClasses = openApiGenerator.GenerateControllerResponseModels(matchingContractSettings);
            foreach (var modelClass in responseClasses)
            {
                spc.AddSource($"{modelClass.ServiceNamespace}_Models_{modelClass.ClassName}.g.cs", modelClass.RenderSource());
            }
        }

        private static void GenerateBehaviourInterfaces(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.BehaviourInterfaces)
            {
                return;
            }

            IList<OpenApiBehaviourInterface> behaviourInterfaces = openApiGenerator.GenerateControllerBehaviours();
            foreach (var behaviourInterface in behaviourInterfaces)
            {
                spc.AddSource($"{behaviourInterface.ServiceNamespace}_Controllers_{behaviourInterface.ClassName}.g.cs", behaviourInterface.RenderSource());
            }
        }

        private static void GenerateControllers(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.Controllers)
            {
                return;
            }

            IList<OpenApiControllerClass> controllers = openApiGenerator.GenerateControllers();
            foreach (var controllerClass in controllers)
            {
                spc.AddSource($"{controllerClass.ServiceNamespace}_Controllers_{controllerClass.ClassName}.g.cs", controllerClass.RenderSource());
            }
        }

        private static void GenerateClientTypes(SourceProductionContext spc, OpenApiSourceFactory openApiGenerator, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.ClientTypes)
            {
                return;
            }

            IList<OpenApiClientClass> clientClasses = openApiGenerator.GenerateClientClass();
            foreach (var clientClass in clientClasses)
            {
                spc.AddSource($"{clientClass.ServiceNamespace}_Client_{clientClass.ClassName}.g.cs", clientClass.RenderSource());
            }

            IList<OpenApiClientInterface> clientInterfaces = openApiGenerator.GenerateClientInterface();
            foreach (var clientInterface in clientInterfaces)
            {
                spc.AddSource($"{clientInterface.ServiceNamespace}_Client_{clientInterface.ClassName}.g.cs", clientInterface.RenderSource());
            }
        }

        private static void GenerateHelperClass(SourceProductionContext spc, ContractSettings matchingContractSettings)
        {
            if (!matchingContractSettings.ContractFilesToGenerate.Helpers)
            {
                return;
            }

            spc.AddSource($"DatesHelper.g.cs", DatesHelper.RenderSource());
        }
    }
}
