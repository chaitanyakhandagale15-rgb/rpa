﻿namespace SBS.WebAPI.Common.ApiSourceGenerator
{
    internal class OpenApiEnum
    {
        public OpenApiEnum(string serviceNamespace, string className, ICollection<object> enumeration)
        {
            ServiceNamespace = serviceNamespace;
            EnumName = className;
            EnumValues = enumeration;
        }

        public string ServiceNamespace { get; }

        public string EnumName { get; }

        public ICollection<object> EnumValues { get; }

        internal string RenderSource()
        {
            string enumNamespace = $"{ServiceNamespace}.Models";
            IEnumerable<string> enumValues = EnumValues.Cast<string>().Where(e => !string.IsNullOrWhiteSpace(e));

            string joinedEnums = string.Join(", \n        ", enumValues);

            return $@"using System.Text.Json;
using System.Text.Json.Serialization;

namespace {enumNamespace}
{{
    [JsonConverter(typeof(JsonStringEnumConverter<{EnumName}>))]
    public enum {EnumName}
    {{
        {joinedEnums}
    }}
}}";
        }
    }
}