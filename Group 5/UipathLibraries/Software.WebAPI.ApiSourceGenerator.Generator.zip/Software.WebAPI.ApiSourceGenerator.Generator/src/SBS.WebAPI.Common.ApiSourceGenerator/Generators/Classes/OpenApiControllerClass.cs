﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

using NJsonSchema;
using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

internal class OpenApiControllerClass
{
    private readonly IDictionary<string, JsonSchema> _schemas;

    private readonly OpenApiPathItem _path;

    public OpenApiControllerClass(string serviceNamespace, string offset, OpenApiPathItem path, IDictionary<string, JsonSchema> schemas)
    {
        ServiceNamespace = serviceNamespace;
        Offset = offset;
        ClassName = OffsetHelpers.CleanOffset(Offset) + "Controller";
        if (path.Summary != null)
        {
            ClassName = $@"{path.Summary}Controller";
        }
        _path = path;
        _schemas = schemas;
    }

    public string ServiceNamespace { get; }

    public string ClassName { get; }

    public string Offset { get; }

    internal string RenderSource()
    {
        string operations = GetOperations();

        return $@"using {ServiceNamespace}.Models;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace {ServiceNamespace}.Controllers
{{
    [ApiController]
    public sealed class {ClassName} : ControllerBase
    {{
        private readonly I{ClassName}Behaviour _behaviour;

        public {ClassName}(I{ClassName}Behaviour behaviour)
        {{
            _behaviour = behaviour;
        }}

        {operations}
    }}
}}";
    }

    private string GetOperations()
    {
        var returnOperations = "";
        foreach (var operation in _path)
        {
            returnOperations += RenderOperation(operation.Key, operation.Value);
            returnOperations += "\r\n";
        }
        return returnOperations;
    }

    private string RenderOperation(string method, OpenApiOperation operation)
    {
        if (operation.OperationId is null)
        {
            throw new InvalidOperationException("An operation did not have an operation ID assigned");
        }

        string operationSignatureParameters = RenderOperationSignatureParameters(operation);
        string methodCallParameters = ParameterHelpers.RenderMethodCallParameters(operation);
        string methodFirstUpper = ("" + method[0]).ToUpper() + method.Substring(1);

        var returnOperation = $@"
        [Http{methodFirstUpper}] 
        [Route(""{Offset}"")]
        public async Task<IActionResult> {operation.OperationId}({operationSignatureParameters})
        {{
            return await this._behaviour.{operation.OperationId}({methodCallParameters});
        }}
";

        return returnOperation;
    }

    private string RenderOperationSignatureParameters(OpenApiOperation operation)
    {
        return string.Join(", ", operation.Parameters.Select(RenderOperationSignatureParameter));
    }

    private string RenderOperationSignatureParameter(OpenApiParameter parameter)
    {
        string parameterType = CSharpHelpers.GetCSharpType(parameter, _schemas);
        string parameterName = ParameterHelpers.ConvertToCamelCase(parameter.Name);

        return $@"{GetOperationSignatureParameterAttributes(parameter)}{parameterType} {parameterName}";
    }

    private static string GetOperationSignatureParameterAttributes(OpenApiParameter parameter)
        => parameter.Kind switch
        {
            OpenApiParameterKind.Header => $@"[FromHeader(Name = ""{parameter.Name}"")] ",
            OpenApiParameterKind.Body => "[FromBody] ",
            _ => string.Empty,
        };
}
