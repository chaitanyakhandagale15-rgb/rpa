﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

using NJsonSchema;
using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;
using System.Globalization;
using System.Text;

internal sealed class OpenApiClientClass
{
    private readonly IDictionary<string, JsonSchema> _schemas;

    private readonly OpenApiPathItem _path;

    public OpenApiClientClass(string serviceNamespace, string offset, OpenApiPathItem path, IDictionary<string, JsonSchema> schemas)
    {
        ServiceNamespace = serviceNamespace;
        Offset = offset;
        ClassName = OffsetHelpers.CleanOffset(Offset) + "Client";
        if (path.Summary != null)
        {
            ClassName = $@"{path.Summary}Client";
        }
        _path = path;
        _schemas = schemas;
    }

    public string ServiceNamespace { get; }

    public string ClassName { get; }

    public string Offset { get; }

    internal string RenderSource()
    {
        string operations = GetOperations();

        return $@"using System.Net.Http.Json;
using System.Security.Policy;
using System.Text;
using System.Threading;
using {ServiceNamespace}.Models;
using Microsoft.AspNetCore.WebUtilities;

namespace {ServiceNamespace}.Client
{{
    public class {ClassName} : I{ClassName}
    {{
        public const string Name = nameof({ClassName});
        private readonly IHttpClientFactory _httpClientFactory;

        public {ClassName}(IHttpClientFactory httpClientFactory)
        {{
            _httpClientFactory = httpClientFactory;
        }}
        {operations}
    }}
}}";
    }

    private string GetOperations()
    {
        var returnOperations = "";
        foreach (var operation in _path)
        {
            returnOperations += RenderOperation(operation.Key, operation.Value);
            returnOperations += "\r\n";
        }
        return returnOperations;
    }

    private string RenderOperation(string method, OpenApiOperation operation)
    {
        string operationName = "";
        if (operation.Summary != null)
        {
            operationName = operation.Summary;
        }
        else
        {
            string offsetForMethodName = OffsetHelpers.CleanOffset(Offset);
            operationName = $@"{method}_{offsetForMethodName}";
        }

        string methodDefinitionParameters = ParameterHelpers.RenderMethodDefinitionCallParameters(operation, _schemas);
        string methodCallParameters = ParameterHelpers.RenderMethodCallParameters(operation);

        string setUrlParameters = SetUrlParameters(operation);
        string addHttpHeaders = AddHttpHeaders(operation);

        var firstOffsetCharacter = Offset.Substring(0, 1);
        var sanitisedOffset = string.Empty;

        if (firstOffsetCharacter.Contains("/"))
        {
            sanitisedOffset = Offset.Remove(0, 1);
        }

        var operationRequest = SetOperationRequest(method, operationName, methodCallParameters, methodDefinitionParameters);

        var returnOperation = $@"
        public async Task<HttpResponseMessage> {operationName}({methodDefinitionParameters})
        {{
            {operationRequest}

            using var httpClient = _httpClientFactory.CreateClient(Name);
{addHttpHeaders}
            return await httpClient.SendAsync(request);
        }}

        private string Build{operationName}Uri({methodDefinitionParameters})
        {{
            var uri = ""{sanitisedOffset}"";
            {setUrlParameters}
            return uri;
        }}";

        return returnOperation;
    }

    private string AddHttpHeaders(OpenApiOperation operation)
    {
        string headersReturn = "";
        foreach (var parameter in operation.Parameters)
        {
            if (parameter.Kind == OpenApiParameterKind.Header)
            {
                string parameterName = ParameterHelpers.ConvertToCamelCase(parameter.Name);
                headersReturn += $@"            httpClient.DefaultRequestHeaders.Add(""{parameter.Name}"", {parameterName});
";
            }
        }

        return headersReturn;
    }

    private string SetUrlParameters(OpenApiOperation operation)
    {
        string parametersReturn = "";
        bool hasQuery = false;
        foreach (var parameter in operation.Parameters)
        {
            switch (parameter.Kind)
            {
                case OpenApiParameterKind.Query:
                    parametersReturn += "uri += \"";
                    if (!hasQuery)
                    {
                        parametersReturn += "?";
                        hasQuery = true;
                    }
                    else
                    {
                        parametersReturn += "&";
                    }
                    parametersReturn += $@"{parameter.Name}="" + " + parameter.Name;
                    parametersReturn += @";
            ";
                    break;
                case OpenApiParameterKind.Path:
                    string parameterConvert = "";
                    if (CSharpHelpers.GetCSharpType(parameter, _schemas) != "string")
                    {
                        parameterConvert = ".ToString()";
                    }
                    parametersReturn += @$"uri = uri.Replace(""{{{parameter.Name}}}"", {parameter.Name}{parameterConvert});
            ";
                    break;
            }
            parametersReturn += "";
        }

        return parametersReturn;
    }

    private string SetOperationRequest(string method, string operationName, string methodCallParameters, string methodDefinitionParameters)
    {
        var formattedMethod = new CultureInfo("en").TextInfo.ToTitleCase(method.ToLower());
        var methodDefinitionParameterList = methodDefinitionParameters.Split(new char[] { ',' });
        var lastMethodParameterIsStringBody = false;

        if (methodDefinitionParameterList.Any() && methodDefinitionParameterList.Last().Contains("string body"))
        {
            lastMethodParameterIsStringBody = true;
        }

        if (method.ToUpperInvariant() == "GET" || method.ToUpperInvariant() == "DELETE" || lastMethodParameterIsStringBody)
        {
            return $@"using var request = new HttpRequestMessage(HttpMethod.{formattedMethod}, Build{operationName}Uri({methodCallParameters}));";
        }
        else
        {
            return $@"using var request = new HttpRequestMessage(HttpMethod.{formattedMethod}, Build{operationName}Uri({methodCallParameters}))
            {{ 
                Content = new StringContent(body.ToJson(), Encoding.UTF8, ""application/json"") 
            }};";
        }
    }
}
