﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

using NJsonSchema;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Tools;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

internal class OpenApiModelClass
{
    private static readonly Regex GetLinesRegex = new("\n", RegexOptions.Compiled);

    private readonly IDictionary<string, JsonSchema> _schemas;

    private readonly ContractSettings _contractSettings;

    public IReadOnlyDictionary<string, JsonSchemaProperty>? Properties = new Dictionary<string, JsonSchemaProperty>();

    public OpenApiModelClass(string serviceNamespace, string className, string baseClass, string classDescription, IDictionary<string, JsonSchema> schemas, ContractSettings contractSettings)
    {
        _schemas = schemas;
        this._contractSettings = contractSettings;
        ServiceNamespace = serviceNamespace;
        ClassName = className;
        ClassDescription = GetClassDescription(classDescription);
        BaseClass = GetBaseClass(baseClass);
        NewKeyword = HideBaseFunction(baseClass);
    }

    public string ServiceNamespace { get; }

    public string ClassName { get; }

    public string ClassDescription { get; }

    public string BaseClass { get; }

    public string NewKeyword { get; }

    internal void AddProperties(IReadOnlyDictionary<string, JsonSchemaProperty> properties)
    {
        if (properties != null)
        {
            Properties = properties;
        }
    }

    internal string RenderSource()
    {
        string classNamespace = $"{ServiceNamespace}.Models";
        string className = ClassName;
        string propertyDefinitions = RenderProperties();

        return $@"#nullable enable

using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Text.Json.Serialization;
using SBS.WebAPI.Common.JSON;

namespace {classNamespace}
{{  
    {ClassDescription}
    [ExcludeFromCodeCoverage]
    public partial class {className}{BaseClass}
    {{  {propertyDefinitions}
        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public {NewKeyword}string ToJson()
        {{
            return JsonSerializer.Serialize(this, new JsonSerializerOptions() {{ WriteIndented = true }});
        }}

        public {NewKeyword}JsonObject ToJsonObjectWithNoUndefinedProperties()
        {{
            return SerializationHelpers.RemoveUndefinedJson(JsonNode.Parse(ToJson())!.AsObject());
        }}
    }}
}}";
    }

    private static string GetClassDescription(string classDescription)
    {
        return string.IsNullOrEmpty(classDescription) ? "" : $@"
    /// <summary>
    /// {classDescription}
    /// </summary>";
    }

    private static string GetBaseClass(string baseClass)
    {
        return string.IsNullOrEmpty(baseClass) ? "" : $" : {baseClass}";
    }

    private static string HideBaseFunction(string baseClass)
    {
        return string.IsNullOrEmpty(baseClass) ? "" : $"new ";
    }

    private string RenderProperties()
    {
        string returnCode = "";
        foreach (var eachProperty in Properties!)
        {
            string cSharpType = CSharpHelpers.GetCSharpType(eachProperty.Value, _schemas);
            string settableCSharpType = AddSettable(eachProperty.Value, cSharpType);
            string annotations = GetAnnotations(eachProperty.Value);
            string defaultValue = GetDefaultValue(eachProperty.Value, cSharpType);
            string propertyNamePascalCase = ConvertToPascalCase(eachProperty.Key);

            returnCode += $@"{RenderSummary(eachProperty.Value.Description)}
        /// <example>{eachProperty.Value.Example}</example>
        {annotations}
        public {settableCSharpType} {propertyNamePascalCase} {{ get; set; }}{defaultValue}
        ";
        }
        return returnCode;
    }

    private string AddSettable(JsonSchemaProperty property, string cSharpType)
    {
        if (!_contractSettings.GenerateSettableProperties || property.IsRequired)
        {
            return cSharpType;
        }

        return $"Settable<{cSharpType}>";
    }

    private string GetDefaultValue(JsonSchemaProperty property, string cSharpType)
    {
        bool shouldBeSettable = _contractSettings.GenerateSettableProperties && !property.IsRequired;

        if (shouldBeSettable || cSharpType.Contains('?'))
        {
            return string.Empty;
        }

        if (property.Type == JsonObjectType.None)
        {
            return $" = new {cSharpType}();";
        }

        if (property.Type == JsonObjectType.Array)
        {
            var propertyTypeWrapper = new JsonSchemaPropertyTypeWrapper(property);

            if (!propertyTypeWrapper.GetNullable())
            {
                return $" = new List{cSharpType.Substring(5)}();";
            }
        }

        return cSharpType switch
        {
            "string" => " = string.Empty;",
            "Guid" => " = Guid.Empty;",
            "Uri" => " = new Uri(\"/\", UriKind.Relative);",
            _ => " = default;",
        };
    }

    private static string RenderSummary(string summary)
    {
        if (summary is null)
        {
            return string.Empty;
        }

        var descriptionLines = GetLinesRegex.Split(summary);

        var isSingleLine = descriptionLines.Length == 1;

        return isSingleLine ? RenderSingleLineSummary() : RenderMultiLineSummary();

        string RenderSingleLineSummary()
        {
            return $"\n        /// <summary>\n        /// {summary}\n        /// </summary>";
        }

        string RenderMultiLineSummary()
        {
            string descriptionSummary = "/// <summary>\n";

            foreach (var item in descriptionLines.Take(descriptionLines.Count() - 1))
            {
                descriptionSummary += string.IsNullOrEmpty(item) ? "\n" : $"        /// {item}\n";
            }

            descriptionSummary += "        /// </summary>";

            return descriptionSummary;
        }
    }

    private static string GetAnnotations(JsonSchemaProperty property)
    {
        string returnCode = $@"[JsonPropertyName(""{property.Name}"")]";

        if (property.Pattern != null)
        {
            if (property.Example != null)
            {
                returnCode += "\r\n        ";
                returnCode += $@"[RegularExpression(@""{property.Pattern}"", ErrorMessage = ""{property.Name} must match format {property.Example}"")]";
            }
            else
            {
                returnCode += "\r\n        ";
                returnCode += $@"[RegularExpression(@""{property.Pattern}"", ErrorMessage = ""{property.Name} must match regex pattern defined in the contract."")]";
            }
        }

        if (property.MinLength != null)
        {
            returnCode += "\r\n        ";
            returnCode += $@"[StringLength({property.MaxLength}, MinimumLength={property.MinLength})]";
        }
        else if (property.MaxLength != null)
        {
            returnCode += "\r\n        ";
            returnCode += $@"[StringLength({property.MaxLength})]";
        }

        return returnCode;
    }

    private static string ConvertToPascalCase(string input)
    {
        if (string.IsNullOrEmpty(input))
            return input;

        return char.ToUpper(input[0]) + input.Substring(1);
    }
}
