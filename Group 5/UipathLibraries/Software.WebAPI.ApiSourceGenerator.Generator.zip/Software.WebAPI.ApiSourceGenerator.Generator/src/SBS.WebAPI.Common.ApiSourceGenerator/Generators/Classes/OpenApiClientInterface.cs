﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

using NJsonSchema;
using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

internal sealed class OpenApiClientInterface
{
    private readonly IDictionary<string, JsonSchema> _schemas;

    private readonly OpenApiPathItem _path;

    public OpenApiClientInterface(string serviceNamespace, string offset, OpenApiPathItem path, IDictionary<string, JsonSchema> schemas)
    {
        ServiceNamespace = serviceNamespace;
        Offset = offset;
        ClassName = "I" + OffsetHelpers.CleanOffset(Offset) + "Client";
        if (path.Summary != null)
        {
            ClassName = $@"I{path.Summary}Client";
        }
        _path = path;
        _schemas = schemas;
    }

    public string ServiceNamespace { get; }

    public string ClassName { get; }

    public string Offset { get; }

    internal string RenderSource()
    {
        string operations = GetOperations();

        return $@"using {ServiceNamespace}.Models;

namespace {ServiceNamespace}.Client
{{
    public interface {ClassName}
    {{
        {operations}
    }}
}}";
    }

    private string GetOperations()
    {
        var returnOperations = "";
        foreach (var operation in _path)
        {
            returnOperations += RenderOperation(operation.Key, operation.Value);
            returnOperations += "\r\n";
        }
        return returnOperations;
    }

    private string RenderOperation(string method, OpenApiOperation operation)
    {
        string operationName = "";
        if (operation.Summary != null)
        {
            operationName = operation.Summary;
        }
        else
        {
            string offsetForMethodName = OffsetHelpers.CleanOffset(Offset);
            operationName = $@"{method}_{offsetForMethodName}";
        }

        string methodDefinitionParameters = ParameterHelpers.RenderMethodDefinitionCallParameters(operation, _schemas);

        var returnOperation = $@"public Task<HttpResponseMessage> {operationName}({methodDefinitionParameters});";

        return returnOperation;
    }
}
