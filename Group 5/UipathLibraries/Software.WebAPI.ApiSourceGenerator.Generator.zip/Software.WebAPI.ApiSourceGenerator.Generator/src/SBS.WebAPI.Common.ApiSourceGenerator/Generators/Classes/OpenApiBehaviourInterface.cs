﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

using NJsonSchema;
using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

internal sealed class OpenApiBehaviourInterface
{
    private readonly IDictionary<string, JsonSchema> _schemas;

    private readonly OpenApiPathItem _path;

    public OpenApiBehaviourInterface(string serviceNamespace, string offset, OpenApiPathItem path, IDictionary<string, JsonSchema> schemas)
    {
        ServiceNamespace = serviceNamespace;
        Offset = offset;
        ClassName = "I" + OffsetHelpers.CleanOffset(Offset) + "ControllerBehaviour";
        if (path.Summary != null)
        {
            ClassName = $@"I{path.Summary}ControllerBehaviour";
        }
        _path = path;
        _schemas = schemas;
    }

    public string ServiceNamespace { get; }

    public string ClassName { get; }

    public string Offset { get; }

    internal string RenderSource()
    {
        string operations = GetOperations();

        return $@"using System.Threading.Tasks;
using {ServiceNamespace}.Models;
using Microsoft.AspNetCore.Mvc;

namespace {ServiceNamespace}.Controllers
{{
    public interface {ClassName}
    {{
        {operations}
    }}
}}";
    }

    private string GetOperations()
    {
        var returnOperations = "";
        foreach (var operation in _path)
        {
            returnOperations += RenderOperation(operation.Value);
            returnOperations += "\r\n";
        }
        return returnOperations;
    }

    private string RenderOperation(OpenApiOperation operation)
    {
        if (operation.OperationId is null)
        {
            throw new InvalidOperationException("An operation did not have an operation ID assigned");
        }

        string methodDefinitionParameters = ParameterHelpers.RenderMethodDefinitionCallParameters(operation, _schemas);

        var returnOperation = $@"public Task<IActionResult> {operation.OperationId}({methodDefinitionParameters});
";

        return returnOperation;
    }
}
