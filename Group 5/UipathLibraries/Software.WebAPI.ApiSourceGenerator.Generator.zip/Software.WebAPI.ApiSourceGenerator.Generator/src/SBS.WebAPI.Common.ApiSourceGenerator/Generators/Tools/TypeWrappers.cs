﻿using NJsonSchema;
using NSwag;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Tools;

internal interface TypeWrapper
{
    public JsonSchema GetObjectReference();
    public string GetFormat();
    public JsonSchema GetArrayItem();
    public bool GetNullable();
    public JsonObjectType GetJsonObjectType();
    public string GetActualFormat();
    public bool GetActualNullable();
    public JsonObjectType GetActualType();
    public JsonSchema GetActualSchema();
}

internal class OpenApiParameterTypeWrapper : TypeWrapper
{
    private OpenApiParameter _wrapped;

    internal OpenApiParameterTypeWrapper(OpenApiParameter wrapped)
    {
        _wrapped = wrapped;
    }

    public string GetActualFormat() => _wrapped.ActualSchema.Format;

    public bool GetActualNullable() => _wrapped.ActualSchema.IsNullableRaw == true;

    public JsonObjectType GetActualType() => _wrapped.ActualSchema.Type;

    public JsonSchema GetArrayItem() => _wrapped.Item;

    public string GetFormat() => _wrapped.Format;

    public bool GetNullable() => _wrapped.IsNullableRaw == true;

    public JsonSchema GetObjectReference() => _wrapped.Reference;

    public JsonObjectType GetJsonObjectType() => _wrapped.Type;

    public JsonSchema GetActualSchema() => _wrapped.ActualSchema;
}

internal class JsonSchemaPropertyTypeWrapper : TypeWrapper
{
    private JsonSchemaProperty _wrapped;

    internal JsonSchemaPropertyTypeWrapper(JsonSchemaProperty wrapped)
    {
        _wrapped = wrapped;
    }

    public string GetActualFormat() => _wrapped.ActualSchema.Format;

    public bool GetActualNullable() => _wrapped.ActualSchema.IsNullableRaw == true;

    public JsonObjectType GetActualType() => _wrapped.ActualSchema.Type;

    public JsonSchema GetArrayItem() => _wrapped.Item;

    public string GetFormat() => _wrapped.Format;

    public bool GetNullable() => _wrapped.IsNullableRaw == true;

    public JsonSchema GetObjectReference() => _wrapped.Reference;

    public JsonObjectType GetJsonObjectType() => _wrapped.Type;

    public JsonSchema GetActualSchema() => _wrapped.ActualSchema;
}
