﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Extensions;

internal static class Extensions
{
    public static string ReplaceWithUnderscore(this string inputString, List<string> charsToChange)
    {
        foreach (string c in charsToChange)
        {
            inputString = inputString.Replace(c, "_");
        }

        return inputString;
    }
}
