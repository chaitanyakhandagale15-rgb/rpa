﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators;

using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;
using System.Collections.Generic;

public class OpenApiSourceFactory
{
    public bool IsParseSuccess { get; } = false;
    public IDictionary<string, NJsonSchema.JsonSchema> Schemas { get; }
    public IDictionary<string, OpenApiPathItem> Paths { get; }
    public string ServiceNamespace { get; }

    private readonly OpenApiDocument _parsedDoc;

    public OpenApiSourceFactory(string content)
    {
        _parsedDoc = OpenApiYamlDocument.FromYamlAsync(content).GetAwaiter().GetResult();

        Schemas = _parsedDoc.Components.Schemas;
        Paths = _parsedDoc.Paths;
        ServiceNamespace = _parsedDoc.Info.Title;
        IsParseSuccess = true;
    }

    internal IList<OpenApiModelClass> GenerateModels(ContractSettings contractSettings)
    {
        IList<OpenApiModelClass> returnModels = new List<OpenApiModelClass>();

        foreach (var schemaName in Schemas.Keys)
        {
            if (Schemas[schemaName].Enumeration.Count is 0)
            {
                var inheritedSchema = Schemas[schemaName].InheritedSchema;
                var parentSchema = inheritedSchema is null ? "" : Schemas.Keys.First(k => Schemas[k].Equals(inheritedSchema));
                OpenApiModelClass newModel = new(ServiceNamespace, schemaName, parentSchema, Schemas[schemaName].Description, Schemas, contractSettings);
                newModel.AddProperties(Schemas[schemaName].ActualProperties);
                returnModels.Add(newModel);
            }
        }

        return returnModels;
    }

    internal IList<OpenApiEnum> GenerateEnums()
    {
        IList<OpenApiEnum> returnEnums = new List<OpenApiEnum>();

        foreach (var schemaName in Schemas.Keys)
        {
            if (Schemas[schemaName].Enumeration.Count is not 0)
            {
                OpenApiEnum newEnum = new(ServiceNamespace, schemaName, Schemas[schemaName].Enumeration);
                returnEnums.Add(newEnum);
            }
        }

        return returnEnums;
    }

    internal IList<OpenApiModelClass> GenerateControllerResponseModels(ContractSettings contractSettings)
    {
        IList<OpenApiModelClass> returnModels = new List<OpenApiModelClass>();

        foreach (var eachPath in Paths)
        {
            foreach (var operation in eachPath.Value)
            {
                foreach (var response in operation.Value.Responses)
                {
                    if (response.Value.Schema != null)
                    {
                        OpenApiModelClass newModel = new(ServiceNamespace, operation.Value.Summary + "Response", string.Empty, response.Value.Schema.Description, Schemas, contractSettings);
                        newModel.AddProperties(response.Value.Schema.ActualProperties);
                        if (newModel.Properties?.Count > 0)
                        {
                            returnModels.Add(newModel);
                        }
                    }
                }
            }
        }

        return returnModels;
    }

    internal IList<OpenApiBehaviourInterface> GenerateControllerBehaviours()
    {
        IList<OpenApiBehaviourInterface> returnBehaviour = new List<OpenApiBehaviourInterface>();

        foreach (var eachPath in Paths)
        {
            OpenApiBehaviourInterface newBehaviour = new(ServiceNamespace, eachPath.Key, eachPath.Value, Schemas);
            returnBehaviour.Add(newBehaviour);
        }

        return returnBehaviour;
    }

    internal IList<OpenApiControllerClass> GenerateControllers()
    {
        IList<OpenApiControllerClass> returnControllers = new List<OpenApiControllerClass>();

        foreach (var eachPath in Paths)
        {
            OpenApiControllerClass newController = new(ServiceNamespace, eachPath.Key, eachPath.Value, Schemas);
            returnControllers.Add(newController);
        }

        return returnControllers;
    }

    internal IList<OpenApiClientClass> GenerateClientClass()
    {
        IList<OpenApiClientClass> returnClientClasses = new List<OpenApiClientClass>();

        foreach (var eachPath in Paths)
        {
            OpenApiClientClass newClientClass = new(ServiceNamespace, eachPath.Key, eachPath.Value, Schemas);
            returnClientClasses.Add(newClientClass);
        }

        return returnClientClasses;
    }

    internal IList<OpenApiClientInterface> GenerateClientInterface()
    {
        IList<OpenApiClientInterface> returnClientInterfaces = new List<OpenApiClientInterface>();

        foreach (var eachPath in Paths)
        {
            OpenApiClientInterface newClientInterface = new(ServiceNamespace, eachPath.Key, eachPath.Value, Schemas);
            returnClientInterfaces.Add(newClientInterface);
        }

        return returnClientInterfaces;
    }
}
