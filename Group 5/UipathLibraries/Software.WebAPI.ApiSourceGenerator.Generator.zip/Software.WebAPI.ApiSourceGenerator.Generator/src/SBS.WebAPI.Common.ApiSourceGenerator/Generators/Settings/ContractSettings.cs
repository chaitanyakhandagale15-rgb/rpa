﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;

using Newtonsoft.Json;

internal sealed class ContractSettings
{
    public ContractSettings(string contractName, bool generateSettableProperties, ContractFilesToGenerate contractFilesToGenerate)
    {
        ContractName = contractName;
        GenerateSettableProperties = generateSettableProperties;
        ContractFilesToGenerate = contractFilesToGenerate;
    }

    [JsonProperty("contractName")]
    public string ContractName { get; set; }

    [JsonProperty("generateSettableProperties")]
    public bool GenerateSettableProperties { get; set; }

    [JsonProperty("filesToGenerate")]
    public ContractFilesToGenerate ContractFilesToGenerate { get; set; }
}
