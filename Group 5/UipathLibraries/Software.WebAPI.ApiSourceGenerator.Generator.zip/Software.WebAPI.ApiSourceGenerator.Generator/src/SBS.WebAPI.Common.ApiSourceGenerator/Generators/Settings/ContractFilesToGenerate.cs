﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

public class ContractFilesToGenerate
{
    [JsonProperty("models")]
    public bool Models { get; set; }

    [JsonProperty("responseClasses")]
    public bool ResponseClasses { get; set; }

    [JsonProperty("behaviourInterfaces")]
    public bool BehaviourInterfaces { get; set; }

    [JsonProperty("controllers")]
    public bool Controllers { get; set; }

    [JsonProperty("clientTypes")]
    public bool ClientTypes { get; set; }

    [JsonProperty("helpers")]
    public bool Helpers { get; set; }
}
