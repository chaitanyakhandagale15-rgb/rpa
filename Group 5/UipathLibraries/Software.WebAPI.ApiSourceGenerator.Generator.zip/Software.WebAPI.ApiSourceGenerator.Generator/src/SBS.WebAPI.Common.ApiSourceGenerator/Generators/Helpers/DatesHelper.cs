﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

internal class DatesHelper
{
    internal static string RenderSource()
    {
        return @"namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

public sealed class DatesHelper
{
    public static DateOnly? DateOnlyFromJadeDateTime(DateTime dateTime)
    {
        return dateTime.Equals(new DateTime(1900, 01, 01)) ? null : DateOnly.FromDateTime(dateTime);
    }

    public static DateOnly? DateOnlyFromJadeDateOnly(DateOnly? dateOnly)
    {
        return dateOnly.Equals(new DateOnly(1900, 01, 01)) ? null : dateOnly;
    }

    public static DateTime? DateTimeFromJadeDateTime(DateTime dateTime)
    {
        return dateTime.Equals(new DateTime(1900, 01, 01)) ? null : dateTime.ToUniversalTime();
    }

    public static DateTime DateOnlyToJadeDateTime(DateOnly? dateOnly)
    {
        return dateOnly.HasValue ? dateOnly.Value.ToDateTime(TimeOnly.MinValue) : new DateTime(1900, 01, 01);
    }
}";
    }
}