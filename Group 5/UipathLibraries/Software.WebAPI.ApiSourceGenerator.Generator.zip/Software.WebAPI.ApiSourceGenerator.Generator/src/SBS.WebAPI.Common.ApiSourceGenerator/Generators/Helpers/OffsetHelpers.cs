﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Extensions;

internal static class OffsetHelpers
{
    public static string CleanOffset(string offset)
    {
        var charsToReplace = new List<string>() { "/", "}", "{", "__" };
        string result = offset.ReplaceWithUnderscore(charsToReplace);
        if (result.StartsWith("_"))
        {
            result = result.Substring(1);
        }
        if (result.EndsWith("_"))
        {
            result = result.Substring(0, result.Length - 1);
        }
        return result;
    }
}
