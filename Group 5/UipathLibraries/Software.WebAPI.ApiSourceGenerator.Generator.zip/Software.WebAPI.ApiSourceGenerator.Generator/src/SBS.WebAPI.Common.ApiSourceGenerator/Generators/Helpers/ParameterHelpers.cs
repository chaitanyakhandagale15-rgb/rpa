﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

using System.Collections.Generic;
using System.Text.RegularExpressions;
using NJsonSchema;
using NSwag;

internal static class ParameterHelpers
{
    public static string RenderMethodCallParameters(OpenApiOperation operation)
    {
        return string.Join(", ", operation.Parameters.Select(parameter => ConvertToCamelCase(parameter.Name)));
    }

    public static string RenderMethodDefinitionCallParameters(OpenApiOperation operation, IDictionary<string, JsonSchema> schemas)
    {
        return string.Join(", ", operation.Parameters.Select(parameter =>
        {
            string parameterType = CSharpHelpers.GetCSharpType(parameter, schemas);
            string parameterName = ConvertToCamelCase(parameter.Name);

            return $@"{parameterType} {parameterName}";
        }));
    }

    internal static string ConvertToCamelCase(string parameterName)
    {
        return Regex.Replace(parameterName, "(-|_).", m => m.Value.ToUpper().Substring(1));
    }
}
