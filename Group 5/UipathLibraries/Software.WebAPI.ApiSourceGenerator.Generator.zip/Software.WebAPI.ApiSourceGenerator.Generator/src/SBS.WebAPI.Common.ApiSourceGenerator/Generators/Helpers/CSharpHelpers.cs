﻿namespace SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

using NJsonSchema;
using NSwag;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Tools;
using System;

internal static class CSharpHelpers
{
    public static string GetCSharpType(OpenApiParameter parameter, IDictionary<string, JsonSchema> schemas)
    {
        return GetCSharpType(new OpenApiParameterTypeWrapper(parameter), schemas);
    }

    public static string GetCSharpType(JsonSchemaProperty property, IDictionary<string, JsonSchema> schemas)
    {
        return GetCSharpType(new JsonSchemaPropertyTypeWrapper(property), schemas);
    }

    private static string GetCSharpType(TypeWrapper property, IDictionary<string, JsonSchema> schemas)
    {
        if (property.GetObjectReference() != null)
        {
            var objReference = schemas.Single(kvp => kvp.Value == property.GetObjectReference()).Key;
            if (property.GetNullable())
            {
                objReference += "?";
            }
            return objReference;
        }

        if (property.GetJsonObjectType() == JsonObjectType.Array)
        {
            return GetArrayItemType(property, schemas);
        }

        if (property.GetJsonObjectType() == JsonObjectType.None)
        {
            try
            {
                return schemas.Single(kvp => kvp.Value == property.GetActualSchema()).Key;
            }
            catch (InvalidOperationException)
            {
                // this is fine - didn't find match
            }

            return GetCSharpSimpleType(property.GetActualFormat(), property.GetActualType(), property.GetActualNullable());
        }

        return GetCSharpSimpleType(property.GetFormat(), property.GetJsonObjectType(), property.GetNullable());
    }

    private static string GetArrayItemType(TypeWrapper property, IDictionary<string, JsonSchema> schemas)
    {
        var arrayItem = property.GetArrayItem();

        string matchingSchema = schemas.SingleOrDefault(kvp => kvp.Value == arrayItem.Reference).Key;

        var returnType = string.Empty;

        if (matchingSchema is not null)
        {
            returnType = $"IList<{matchingSchema}>";
        }
        else
        {
            returnType = $"IList<{GetCSharpSimpleType(arrayItem.Format, arrayItem.Type, arrayItem.IsNullableRaw == true)}>";
        }

        if (property.GetNullable())
        {
            returnType += "?";
        }

        return returnType;
    }

    private static string GetCSharpSimpleType(string formatString, JsonObjectType type, bool nullable)
    {
        string returnType = "";

        switch (type)
        {
            case JsonObjectType.Boolean:
                returnType = "bool";
                break;
            case JsonObjectType.File:
                returnType = "byte[]";
                break;
            case JsonObjectType.Integer:
                returnType = formatString switch
                {
                    "int64" => "long",
                    "int32" => "int",
                    _ => "int",
                };
                break;
            case JsonObjectType.Null:
                returnType = "void";
                break;
            case JsonObjectType.Number:
                returnType = formatString switch
                {
                    "float" => "float",
                    "double" => "double",
                    "decimal" => "decimal",
                    _ => "decimal",
                };
                break;
            case JsonObjectType.Object:
                returnType = "ObjectNotImplemented";
                break;
            case JsonObjectType.String:
                returnType = formatString switch
                {
                    "date" => "DateOnly",
                    "date-time" => "DateTime",
                    "uuid" => "Guid",
                    "url" => "Uri",
                    "binary" => "byte[]",
                    _ => "string",
                };
                break;
        }

        if (nullable)
        {
            returnType += "?";
        }

        return returnType;
    }
}
