# Introduction   
This repository contains a [Roslyn Incremental Generator](https://github.com/dotnet/roslyn/blob/main/docs/features/incremental-generators.md) that will take a provided OpenAPI 3 .yaml specification file and generate C# code for it.  Generated classes are automatically updated when the .yaml file changes, and they will be available to be viewed in Dependencies/Analyzers/ApiSourceGenerator.

The following types of classes are generated:
* Controllers.  These are the AspNetCore.Mvc classes that expose web endpoints.  These delegate through to a Behaviour class using dependency injection.
* Behaviour Interfaces.  These are the interfaces that the Controller calls for each exposed operation.  The implementation of this will differ per service, and so the class that implements this interface will be built manually.
* Models.  These are representations of the Schemas defined within the .yaml definition, and they are used as call and response parameters on the operations this API exposes.
* Response classes.  These are the structures defined directly as responses on endpoints in the .yaml definition
* Client types.  There is an interface and a class to be used to call operations.  These can again be dependency injected.
* Helpers.  This generates a DatesHelper class which is used to map DateOnly and DateTime back and forth to Jade.

These generated files are available inside Visual Studio, inside the project that the generator is installed for.  Look in Dependencies/Analyzers/SBS.WebAPI.Common.ApiSourceGenerator/SNS.WebAPI.Common.ApiSourceGenerator.ApiSourceGenerator+OpenApiGenerator.  If this section shows "This generator is not generating files" then the generator has a problem and you'll need to start investigating why.

## Usage
In order to use the generator, it needs to be included into a project using Nuget. Ths can be included by running the following command in the Package Manager Console - 

    install-package SBS.WebAPI.Common.ApiSourceGenerator

It is also sometimes useful to set the following properties temporarily in the csproj file:

    <PropertyGroup>
        <EmitCompilerGeneratedFiles>false</EmitCompilerGeneratedFiles>
        <CompilerGeneratedFilesOutputPath>Generated</CompilerGeneratedFilesOutputPath>
    </PropertyGroup>

Setting __EmitCompilerGeneratedFiles__ to __true__ makes it so you can see the generated source files when the generator is failing.  This is useful to investigate what is happening when things aren't working.

### Files the generator looks for
There are currently two types of files that the generator looks for.  For these files to be picked up by the generator, they will need to have a Build Action set to __C# Analyser additional file__.  Failure to do this is a common issue in the generator not generating anything.

#### Canary.txt
If there is a Canary.txt file in the project, it will cause a constants class to be generated.  This is useful to make sure that the generator is installed and working - it doesn't need a yaml file.  The generated file will be called ConstStrings.Canary.g.cs and it will have a constant in it called Canary with the text from the text file.

#### .yaml
Any file that ends in '.yaml' is picked up and parsed as an OpenApi YAML file. Whenever this file changes, the generation process is re-run.  If this fails to parse, the generation process will likely fail and no files will be generated, so ensure only valid specifications are used - the linter in the common.contracts repository helps with this.  Remember to set the Build Action as talked about above.

#### contractSettings.json
The generator will also search for a __`contractSettings.json`__ file.  This is where the user can specify which types of files should be generated, by setting an appropriate json value to true or false.  Additionally, this json file can include references to multiple contracts, giving the user control over which files to generate for each contract.

    [
        {
            // Contract 1 files to generate
            "contractName": "SBS.WebAPI.SkiptonOnline.Experience",
            "filesToGenerate": {
                "models": false,
                "responseClasses": true,
                "behaviourInterfaces": false,
                "controllers": true,
                "clientTypes": true,
                "helpers": true
            }
        },
        {
            // Contract 2 files to generate
            "contractName": "SBS.WebAPI.SkiptonOnline.Domain.Data",
            "filesToGenerate": {
                "models": true,
                "responseClasses": false,
                "behaviourInterfaces": true,
                "controllers": false,
                "clientTypes": false,
                "helpers": false
            }
        }
    ]

This json file needs to be configured with a Build Action set to __C# Analyser additional file__.

The __`contractName`__ strings here need to match the name of the .yaml file, or nothing will be generated.

The Experience layer projects typically have three projects using the generator.  
* The ContractResources project generates files for the contract that this project offers up to callers, so in the case of Experience.SkiptonOnlinePortal this is the experience layer contract.
* The Dispatcher project defines the Clients and Models for the domain APIs that are called from this code.
* The Dispatcher.Test project defines the Controllers and ControllerBehaviour interfaces that are used during testing.  We don't want to generate these as part of the main Dispatcher project as they would end up in the production api.

For a domain layer project, we typically just have the one ContractResources project.  As these projects typically call through to Jade, this is done using a standard interface.

## Copying In Contracts
We use the SBS.WebAPI.Common.Contracts repository as the single source of truth for yaml contracts.  We therefore don't want to manually copy the contracts into each repository where they are used, we want that to happen automatically as part of the build process.

To this end, we package up all the contracts into a nuget package when they are merged to main, and these files can then be automatically copied in at build time.

To include the nuget package and get access to these files, we need the following:

    <PackageReference Include="SBS.WebAPI.Common.Contracts" Version="2.0.2206" GeneratePathProperty="true" />

Once that is in place, we can copy out the specific version of the yaml file we need

	<ItemGroup>
		<SpecFiles Include="$(PkgSBS_WebAPI_Common_Contracts)\SBS.WebAPI.Experience.SkiptonOnlinePortal\4.0.5\*.yaml"></SpecFiles>
	</ItemGroup>

We also must ensure that these files are copied to the output directory:

	<ItemGroup>
		<AdditionalFiles Include="@(SpecFiles)" CopyToOutputDirectory="Always" />
		<AdditionalFiles Include="contractSettings.json" CopyToOutputDirectory="Always" />
	</ItemGroup>

## Unit Testing
There are several unit tests available within this repository which check that the generated code makes sense.  This is no guarantee it'll compile when it gets in a real project.

## Features and Limitations
This generator has currently been developed on a subset of the OpenAPI 3 specification. There will be situations it can't cope with and it will need to be changed to support them, or the contract changed to be simpler.

This section lists some of the more complex features that are supported.

### Class and Method Names
Class and method names are taken from the summary and operationId fields.  Typically a service is defined like this:

    /accounts/{customerNumber}/savings/{accountNumber}/details:
      summary: SavingsAccountDetails
      get:
        operationId: GetCustomerSavingsAccountDetails

In this case __`SavingsAccountDetails`__ will be used as the start of the class name, and __`GetCustomerSavingsAccountDetails`__ will be a method on it.

A common cause of problems is where the summary isn't unique and the generator tries to create multiple classes with the same name.

### Response Objects
Response objects can be defined inline like this:

    responses:
      '200':
        description: OK
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/SavingsAccount'

To define a response an an array, use this format

    responses:
      '200':
        description: OK
        content:
          application/json:
            schema:
              type: object
              properties:
                transactions:
                  type: array
                  items:
                    $ref: '#/components/schemas/SavingsTransaction'

The array always needs to have a name (in this case __`transactions`__), we don't support returning top level arrays.

### Inheritance
It's possible to inherit objects by using allOf.  

    SavingsAccount:
      allOf:
        - $ref: '#/components/schemas/SavingsAccountSummary'
        - type: object
      properties:
        withdrawalPenaltyNotice:
          type: string
          example: This is a withdrawal penalty notice
        hideAllowanceForLisa:
          type: boolean
          example: true

This will generate a SavingsAccountSummary class, and a SavingsAccount class that inherits from it.

### allOf, oneOf, anyOf
These elements are largely not supported, except the use of allOf for inheritance as outlined above.

oneOf can be used in combination with required, like this:

    required:
      - transactionAmount
    oneOf:
      - required:
        - targetAccountNumber
      - required:
        - targetNominatedAccountNumber
        - targetNominatedAccountSortCode

When doing this, ensure that the oneOf is at the same level as the required, not inside it.

anyOf is not supported.

## Troubleshooting
If you're not getting any files generated, check the following:
* You've used the approach outlined in __Copying In Contracts__ above, and have the files copied to the output directory
* Your .yaml file name matches the .yaml file name
* The .yaml file and the __`contractSettings.json`__ file are correctly set up with a build type of __C# Analyser additional file__
* Make sure the import of Common.Contracts has GeneratePathProperty set to true.  See the example above.
* Restart Visual Studio.  This is usually required after changing the contents of __`contractSettings.json`__, but is also worth doing if things aren't working, it sometimes kicks it into life.
* Try not to overwrite the copied in .yaml file with new contents and save it.  If you do, you've updated your local nuget cache and the copy at build time won't be overwriting it any more, so you'll not get any updates.  The way to fix it if this happens is to delete your local nuget cache - it's probably somewhere like C:\Users\57120\.nuget\packages\sbs.webapi.common.contracts

 
## Example Project
The best example of the generator in use is to look at the Experience.SkiptonOnlinePortal project, or Domain.SavingsAccounts.  These are both making full use of the generator to deliver a working solution.