﻿using Microsoft.CodeAnalysis;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests
{
    [UsesVerify]
    public class OpenApiGeneratorSnapshotErrorTests
    {
        private readonly List<AdditionalText> additionalTexts = new();
        private readonly SnapshotHelper snapshotHelper;

        public OpenApiGeneratorSnapshotErrorTests()
        {

            snapshotHelper = new SnapshotHelper();
        }

        [Fact]
        public Task GeneratorRan_MalformedContractSettings_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsMalformed.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            var exception = runResult.Exception;
            return Verify(exception);
        }

        [Fact]
        public Task GeneratorRan_WrongContractName_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsWrongContractName.json"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            var exception = runResult.Exception;
            return Verify(exception);
        }

        [Fact]
        public Task GeneratorRan_NoOperationId_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettings.json"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/Dummy.Contract.NoOperationId.yaml"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            var exception = runResult.Exception;
            return Verify(exception);
        }
    }
}
