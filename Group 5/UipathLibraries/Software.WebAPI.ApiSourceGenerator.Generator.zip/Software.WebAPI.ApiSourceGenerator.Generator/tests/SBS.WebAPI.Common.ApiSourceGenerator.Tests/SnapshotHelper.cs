﻿using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis;
using System.Collections.Immutable;
using static SBS.WebAPI.Common.ApiSourceGenerator.ApiSourceGenerator;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests
{
    public class SnapshotHelper
    {
        public GeneratorDriver GeneratorDriver(List<AdditionalText> additionalTexts)
        {
            var compilation = CSharpCompilation.Create("name");
            var generator = new OpenApiGenerator();

            var driver = CSharpGeneratorDriver
                .Create(generator)
                .AddAdditionalTexts(ImmutableArray.CreateRange(additionalTexts));

            return driver.RunGenerators(compilation);
        }
    }
}
