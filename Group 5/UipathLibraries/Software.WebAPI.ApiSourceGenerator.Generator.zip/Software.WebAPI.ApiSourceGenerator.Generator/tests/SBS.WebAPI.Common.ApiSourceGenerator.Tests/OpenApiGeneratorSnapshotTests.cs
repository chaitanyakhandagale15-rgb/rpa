﻿using Microsoft.CodeAnalysis;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests
{
    [UsesVerify]
    public class OpenApiGeneratorSnapshotTests
    {
        private readonly List<AdditionalText> additionalTexts = new();
        private readonly SnapshotHelper snapshotHelper;
        private readonly string yamlFile = "SBS.WebAPI.SkiptonOnline.Example.yaml";

        public OpenApiGeneratorSnapshotTests()
        {
            snapshotHelper = new SnapshotHelper();
        }

        [Fact]
        public Task GeneratorRan_ValidFiles_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettings.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();

            return Verify(runResult);
        }

        [Fact]
        public Task GeneratorRan_OnlyModels_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsOnlyModels.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();

            return Verify(runResult);
        }

        [Fact]
        public Task GeneratorRan_OnlyBehaviourInterfaces_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsOnlyBehaviourInterfaces.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            return Verify(runResult);
        }

        [Fact]
        public Task GeneratorRan_OnlyClientTypes_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsOnlyClientTypes.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            return Verify(runResult);
        }

        [Fact]
        public Task GeneratorRan_OnlyControllers_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsOnlyControllers.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            return Verify(runResult);
        }

        [Fact]
        public Task GeneratorRan_OnlyResponseClasses_ExpectedOutput()
        {
            additionalTexts.Add(new CustomAdditionalText(@$"./Resources/{yamlFile}"));
            additionalTexts.Add(new CustomAdditionalText(@"./Resources/ContractSettings/contractSettingsOnlyResponseClasses.json"));

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var runResult = driver.GetRunResult().Results.Single();
            return Verify(runResult);
        }
    }
}
