using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests;

public class CleanParameterNameTests
{
    [Theory]
    [InlineData("kebab-case", "kebabCase")]
    [InlineData("parameter-name", "parameterName")]
    public void TestCleanParameterName_WorksWithKebabCase(string parameterName, string expectedResult)
    {
        string result = ParameterHelpers.ConvertToCamelCase(parameterName);
        result.Should().Be(expectedResult);
    }

    [Theory]
    [InlineData("snake_case", "snakeCase")]
    [InlineData("param_name", "paramName")]
    public void TestCleanParameterName_WorksWithUnderscores(string parameterName, string expectedResult)
    {
        string result = ParameterHelpers.ConvertToCamelCase(parameterName);
        result.Should().Be(expectedResult);
    }

    [Theory]
    [InlineData("camelCase", "camelCase")]
    [InlineData("TitleCase", "TitleCase")]
    public void TestCleanParameterName_WorksWithAlreadyCleanValues(string parameterName, string expectedResult)
    {
        string result = ParameterHelpers.ConvertToCamelCase(parameterName);
        result.Should().Be(expectedResult);
    }
}