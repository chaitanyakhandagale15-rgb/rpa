﻿using System.Runtime.CompilerServices;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests
{
    public static class ModuleInitializer
    {
        [ModuleInitializer]
        public static void Init()
        {
            VerifySourceGenerators.Initialize();
        }
    }
}