using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests;

[UsesVerify]
public class YamlReponseModelGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedResponseModelHasCorrectImports()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateControllerResponseModels(contractSettings);

        models.Count.Should().Be(1);

        models[0].RenderSource().Should().Contain("using System.Text.Json;");
        models[0].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[0].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedResponseModelHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateControllerResponseModels(contractSettings);

        models.Count.Should().Be(1);

        models[0].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
    }

    [Fact]
    public async Task GivenYamlFileIsParsed_ThenGeneratedResponseModelHasCorrectClassNameDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateControllerResponseModels(contractSettings);

        await Verify(models[0].RenderSource()); //Verify output hasn't changed

        models.Count.Should().Be(1);
        models[0].ClassName.Should().Be("GetDashboardForCustomerResponse");
        models[0].RenderSource().Should().Contain("public partial class GetDashboardForCustomerResponse");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedResponseModelHasCorrectAttributesDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateControllerResponseModels(contractSettings);

        models.Count.Should().Be(1);
        models[0].ClassName.Should().Be("GetDashboardForCustomerResponse");
        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"customer\")]");
        models[0].RenderSource().Should().Contain("public Customer Customer");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"savingsAccounts\")]");
        models[0].RenderSource().Should().Contain("public IList<SavingsAccount> SavingsAccounts");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"mortgageAccounts\")]");
        models[0].RenderSource().Should().Contain("public IList<MortgageAccount> MortgageAccounts");
    }
}