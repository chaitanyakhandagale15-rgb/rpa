using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlTests;

public class YamlParserTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenParseSucceeded()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        sourceFactory.IsParseSuccess.Should().Be(true);
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenParsedModelsAreAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        sourceFactory.Schemas.Count.Should().Be(9);
        sourceFactory.Schemas.Keys.Should().Contain("Customer");
        sourceFactory.Schemas.Keys.Should().Contain("SavingsAccount");
        sourceFactory.Schemas.Keys.Should().Contain("MortgageAccount");
        sourceFactory.Schemas.Keys.Should().Contain("UpdateCustomerSavingsAccountDetailsRequest");
        sourceFactory.Schemas.Keys.Should().Contain("ProblemDetails");
        sourceFactory.Schemas.Keys.Should().Contain("WebApiError");
        sourceFactory.Schemas.Keys.Should().Contain("WebApiErrorDetails");
        sourceFactory.Schemas.Keys.Should().Contain("InterestDestination");
        sourceFactory.Schemas.Keys.Should().Contain("BankDetails");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenNamespaceAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        sourceFactory.ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenModelNameAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);
        models[0].ClassName.Should().Be("Customer");
        models[0].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[0].ClassDescription.Should().Be("");

        models[1].ClassName.Should().Be("SavingsAccount");
        models[1].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[1].ClassDescription.Should().Be("");

        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[2].ClassDescription.Should().Be("");

        models[3].ClassName.Should().Be("UpdateCustomerSavingsAccountDetailsRequest");
        models[3].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[3].ClassDescription.Should().Be("");

        models[4].ClassName.Should().Be("ProblemDetails");
        models[4].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[4].ClassDescription.Should().Be("");

        models[5].ClassName.Should().Be("WebApiError");
        models[5].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[5].ClassDescription.Should().Be("");

        models[6].ClassName.Should().Be("WebApiErrorDetails");
        models[6].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[6].ClassDescription.Should().Be("");

        models[7].ClassName.Should().Be("InterestDestination");
        models[7].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[7].ClassDescription.Should().Be("");

        models[8].ClassName.Should().Be("BankDetails");
        models[8].ServiceNamespace.Should().Be("Software.WebAPI.SkiptonOnline.Experience");
        models[8].ClassDescription.Should().Be("");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenModelPropertiesAreAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[0].ClassName.Should().Be("Customer");
        models[0].Properties!.Count.Should().Be(6);
        models[0].Properties!.Keys.Should().Contain("customerNumber");
        models[0].Properties!.Keys.Should().Contain("firstName");
        models[0].Properties!.Keys.Should().Contain("lastName");
        models[0].Properties!.Keys.Should().Contain("middleName");
        models[0].Properties!.Keys.Should().Contain("birthDate");
        models[0].Properties!.Keys.Should().Contain("salutation");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenModelPropertiesHaveTypeDataAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        // nullable date
        models[1].ClassName.Should().Be("SavingsAccount");
        models[1].Properties!.Keys.Should().Contain("maturityDate");
        models[1].Properties!["maturityDate"].Type.Should().Be(NJsonSchema.JsonObjectType.String);
        models[1].Properties!["maturityDate"].Format.Should().Be("date");
        models[1].Properties!["maturityDate"].MinLength.Should().Be(0);
        models[1].Properties!["maturityDate"].MaxLength.Should().Be(30);
        models[1].Properties!["maturityDate"].Example.Should().Be("2024-08-20");
        models[1].Properties!["maturityDate"].IsNullableRaw.Should().Be(true);

        // non-nullable string
        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].Properties!.Keys.Should().Contain("accountFriendlyName");
        models[2].Properties!["accountFriendlyName"].Type.Should().Be(NJsonSchema.JsonObjectType.String);
        models[2].Properties!["accountFriendlyName"].Format.Should().BeNull();
        models[2].Properties!["accountFriendlyName"].MinLength.Should().Be(0);
        models[2].Properties!["accountFriendlyName"].MaxLength.Should().Be(30);
        models[2].Properties!["accountFriendlyName"].Example.Should().Be("87 Belthron Road, BB1 2NN");
        models[2].Properties!["accountFriendlyName"].IsNullableRaw.Should().BeNull();

        // non-nullable number
        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].Properties!.Keys.Should().Contain("monthlyPayment");
        models[2].Properties!["monthlyPayment"].Type.Should().Be(NJsonSchema.JsonObjectType.Number);
        models[2].Properties!["monthlyPayment"].Format.Should().Be("double");
        models[2].Properties!["monthlyPayment"].MinLength.Should().BeNull();
        models[2].Properties!["monthlyPayment"].MaxLength.Should().BeNull();
        models[2].Properties!["monthlyPayment"].Example.Should().Be("500.00");
        models[2].Properties!["monthlyPayment"].IsNullableRaw.Should().BeNull();
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenModelPropertiesHaveCSharpDataTypeAvailableInCode()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        // nullable date
        models[1].ClassName.Should().Be("SavingsAccount");
        models[1].Properties!.Keys.Should().Contain("maturityDate");

        // non-nullable string
        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].Properties!.Keys.Should().Contain("accountFriendlyName");

        // non-nullable number
        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].Properties!.Keys.Should().Contain("monthlyPayment");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenPathsAreAvailableInControllersGenerator()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        // nullable date
        controllers.Count.Should().Be(7);

        controllers[0].Offset.Should().Be("/dashboard/{customerNumber}");
        controllers[0].ClassName.Should().Be("DashboardForCustomerController");

        controllers[1].Offset.Should().Be("/account/{accountNumber}");
        controllers[1].ClassName.Should().Be("AccountController");

        controllers[2].Offset.Should().Be("/profile/{customerNumber}");
        controllers[2].ClassName.Should().Be("profile_customerNumberController");

        controllers[3].Offset.Should().Be("/accounts/{customerNumber}/savings/{accountNumber}/details");
        controllers[3].ClassName.Should().Be("SavingsAccountDetailsController");

        controllers[4].Offset.Should().Be("/accounts/{customerNumber}/savings/{accountNumber}/interest-destination");
        controllers[4].ClassName.Should().Be("InterestDestinationController");

        controllers[5].Offset.Should().Be("/accounts/{customerNumber}/savings/{accountNumber}/create-interest-destination");
        controllers[5].ClassName.Should().Be("InterestDestinationCreateController");

        controllers[6].Offset.Should().Be("/accounts/{customerNumber}/savings/{accountNumber}/nominated-accounts/{nominatedAccountId}");
        controllers[6].ClassName.Should().Be("NominatedAccountsDeleteController");
    }
}