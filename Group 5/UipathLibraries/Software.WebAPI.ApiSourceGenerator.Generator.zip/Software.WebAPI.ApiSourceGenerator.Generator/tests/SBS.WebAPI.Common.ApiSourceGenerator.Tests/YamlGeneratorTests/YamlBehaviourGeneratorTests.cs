using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlTests;

[UsesVerify]
public class YamlBehaviourGeneratorTests
{
    [Fact]
    public async Task GivenYamlFileIsParsed_ThenGeneratedBehaviourHasCorrectImports()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(7);

        behaviours[0].RenderSource().Should().Contain("using Microsoft.AspNetCore.Mvc;");

        await Verify(behaviours[0].RenderSource())
            .ScrubLines(x => !x.StartsWith("using "));
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedBehaviourHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(7);

        behaviours[0].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[1].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[2].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[3].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[4].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[5].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        behaviours[6].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");

        await Verify(behaviours[6].RenderSource())
            .ScrubLines(x => !x.StartsWith("namespace "));
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedBehaviourHasCorrectClassName()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(7);

        behaviours[0].RenderSource().Should().Contain("public interface IDashboardForCustomerControllerBehaviour");
        behaviours[1].RenderSource().Should().Contain("public interface IAccountControllerBehaviour");
        behaviours[2].RenderSource().Should().Contain("public interface Iprofile_customerNumberControllerBehaviour");
        behaviours[3].RenderSource().Should().Contain("public interface ISavingsAccountDetailsControllerBehaviour");
        behaviours[4].RenderSource().Should().Contain("public interface IInterestDestinationControllerBehaviour");
        behaviours[5].RenderSource().Should().Contain("public interface IInterestDestinationCreateControllerBehaviour");
        behaviours[6].RenderSource().Should().Contain("public interface INominatedAccountsDeleteControllerBehaviour");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedBehaviourHasCorrectOperationFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(7);

        behaviours[0].RenderSource().Should().Contain("public Task<IActionResult> GetDashboardForCustomer(long customerNumber)");
        behaviours[1].RenderSource().Should().Contain("public Task<IActionResult> GetAccount(long accountNumber)");
        behaviours[2].RenderSource().Should().Contain("public Task<IActionResult> GetProfile(long customerNumber, string source, string source2)");
        behaviours[3].RenderSource().Should().Contain("public Task<IActionResult> UpdateCustomerSavingsAccountDetails(string customerNumber, int accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, UpdateCustomerSavingsAccountDetailsRequest body)");
        behaviours[4].RenderSource().Should().Contain("public Task<IActionResult> ChangeSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        behaviours[5].RenderSource().Should().Contain("public Task<IActionResult> CreateSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        behaviours[6].RenderSource().Should().Contain("public Task<IActionResult> DeleteSavingsNominatedAccount(string customerNumber, int accountNumber, int nominatedAccountId, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress)");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerWithFilesHasCorrectParametersToFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Fax.Files.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(1);

        behaviours[0].RenderSource().Should().Contain("public Task<IActionResult> FileUpload(FaxFileCall body);");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFaxControllerWithFilesHasCorrectParametersToFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Telephony.Fax.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiBehaviourInterface> behaviours = sourceFactory.GenerateControllerBehaviours();

        behaviours.Count.Should().Be(1);

        behaviours[0].RenderSource().Should().Contain("public Task<IActionResult> SendFax(string apiKey, string version, string systemId, string sessionId, string messageId, Fax body);");
    }
}