﻿using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlGeneratorTests.ClientClassGeneratorTests;

public class PostClientClassGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectOperationFunction_WithCorrectRequest()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        string expected = @"
            using var request = new HttpRequestMessage(HttpMethod.Post, BuildChangeSavingsInterestDestinationUri(customerNumber, accountNumber, authorization, apiKey, version, systemId, sessionId, messageId, ipAddress, body))
            { 
                Content = new StringContent(body.ToJson(), Encoding.UTF8, ""application/json"") 
            };";

        classes[4].RenderSource().Should().Contain(expected);
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedBackendClientClassHasCorrectOperationFunction_WithCorrectRequest()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Backends.Jade.SavingsAccounts.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(6);
        _ = classes[0].RenderSource();

        string expected = @"using var request = new HttpRequestMessage(HttpMethod.Post, BuildGetSavingsAccountsUri(messageId, sessionId, systemId, version, body));";

        classes[0].RenderSource().Should().Contain(expected);
    }
}
