﻿using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.DataCollection;
using System.Net.Http;
using System.Net;
using YamlDotNet.Core;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlGeneratorTests.ClientClassGeneratorTests;

public class DeleteClientClassGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectOperationFunction_WithCorrectRequest()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        string expected = @"using var request = new HttpRequestMessage(HttpMethod.Delete, BuildDeleteSavingsNominatedAccountUri(customerNumber, accountNumber, nominatedAccountId, authorization, apiKey, version, systemId, sessionId, messageId, ipAddress));";

        classes[6].RenderSource().Should().Contain(expected);
    }
}
