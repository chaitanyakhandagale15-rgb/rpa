using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlTests;

public class GeneralClientClassGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectImports()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);

        classes[0].RenderSource().Should().Contain("Microsoft.AspNetCore.WebUtilities;");
        classes[0].RenderSource().Should().Contain("System.Net.Http.Json;");
        classes[0].RenderSource().Should().Contain("System.Security.Policy;");
        classes[0].RenderSource().Should().Contain("System.Threading;");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);

        Assert.All(classes, x => x.RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience"));
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectClassName()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);

        classes[0].RenderSource().Should().Contain("public class DashboardForCustomerClient");
        classes[1].RenderSource().Should().Contain("public class AccountClient");
        classes[2].RenderSource().Should().Contain("public class profile_customerNumberClient");
        classes[3].RenderSource().Should().Contain("public class SavingsAccountDetailsClient");
        classes[4].RenderSource().Should().Contain("public class InterestDestinationClient");
        classes[5].RenderSource().Should().Contain("public class InterestDestinationCreate");
        classes[6].RenderSource().Should().Contain("public class NominatedAccountsDeleteClient");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectOperationFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        classes[0].RenderSource().Should().Contain("public async Task<HttpResponseMessage> GetDashboardForCustomer(long customerNumber)");
        classes[1].RenderSource().Should().Contain("public async Task<HttpResponseMessage> GetAccount(long accountNumber)");
        classes[2].RenderSource().Should().Contain("public async Task<HttpResponseMessage> get_profile_customerNumber(long customerNumber, string source, string source2)");
        classes[3].RenderSource().Should().Contain("public async Task<HttpResponseMessage> UpdateCustomerSavingsAccountDetails(string customerNumber, int accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, UpdateCustomerSavingsAccountDetailsRequest body)");
        classes[4].RenderSource().Should().Contain("public async Task<HttpResponseMessage> ChangeSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        classes[5].RenderSource().Should().Contain("public async Task<HttpResponseMessage> CreateSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        classes[6].RenderSource().Should().Contain("public async Task<HttpResponseMessage> DeleteSavingsNominatedAccount(string customerNumber, int accountNumber, int nominatedAccountId, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress)");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectBuildUriFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        string expected0 = "uri = uri.Replace(\"{customerNumber}\", customerNumber.ToString());";
        classes[0].RenderSource().Should().Contain(expected0);

        string expected1 = "uri = uri.Replace(\"{accountNumber}\", accountNumber.ToString());";
        classes[1].RenderSource().Should().Contain(expected1);

        string expected2_1 = "uri = uri.Replace(\"{customerNumber}\", customerNumber.ToString());";
        string expected2_2 = "uri += \"?source=\" + source;";
        string expected2_3 = "uri += \"&source2=\" + source2;";
        classes[2].RenderSource().Should().Contain(expected2_1);
        classes[2].RenderSource().Should().Contain(expected2_2);
        classes[2].RenderSource().Should().Contain(expected2_3);

        string expected3 = "uri = uri.Replace(\"{customerNumber}\", customerNumber);";
        classes[3].RenderSource().Should().Contain(expected3);

        string expected4 = "uri = uri.Replace(\"{customerNumber}\", customerNumber);";
        classes[4].RenderSource().Should().Contain(expected4);

        string expected5 = "uri = uri.Replace(\"{customerNumber}\", customerNumber);";
        classes[5].RenderSource().Should().Contain(expected5);

        string expected6 = "uri = uri.Replace(\"{customerNumber}\", customerNumber);";
        classes[6].RenderSource().Should().Contain(expected6);
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFaxClientClassHasCorrectBuildUriFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Telephony.Fax.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(1);
        _ = classes[0].RenderSource();

        // TODO fix these tests for the new yaml
        string expected0 = "httpClient.DefaultRequestHeaders.Add(\"api-key\", apiKey);";
        classes[0].RenderSource().Should().Contain(expected0);

        string expected1 = "httpClient.DefaultRequestHeaders.Add(\"version\", version);";
        classes[0].RenderSource().Should().Contain(expected1);

        string expected2 = "httpClient.DefaultRequestHeaders.Add(\"system-id\", systemId);";
        classes[0].RenderSource().Should().Contain(expected2);
    }
}
