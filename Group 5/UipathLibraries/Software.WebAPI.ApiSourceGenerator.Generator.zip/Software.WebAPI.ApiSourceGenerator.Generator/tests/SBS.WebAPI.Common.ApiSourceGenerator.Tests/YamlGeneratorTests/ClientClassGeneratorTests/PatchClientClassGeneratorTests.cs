﻿using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlGeneratorTests.ClientClassGeneratorTests;

public class PatchClientClassGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectOperationFunction_WithCorrectRequest()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        string expected = @"
            using var request = new HttpRequestMessage(HttpMethod.Patch, BuildUpdateCustomerSavingsAccountDetailsUri(customerNumber, accountNumber, authorization, apiKey, version, systemId, sessionId, messageId, ipAddress, body))
            { 
                Content = new StringContent(body.ToJson(), Encoding.UTF8, ""application/json"") 
            };";

        classes[3].RenderSource().Should().Contain(expected);
    }
}
