﻿using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlGeneratorTests.ClientClassGeneratorTests;

public class GetClientClassGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientClassHasCorrectOperationFunction_WithCorrectRequest()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientClass> classes = sourceFactory.GenerateClientClass();

        classes.Count.Should().Be(7);
        _ = classes[0].RenderSource();

        string expected = @"using var request = new HttpRequestMessage(HttpMethod.Get, BuildGetDashboardForCustomerUri(customerNumber));";

        classes[0].RenderSource().Should().Contain(expected);
    }
}
