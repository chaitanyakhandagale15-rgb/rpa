using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Settings;
using Xunit.Sdk;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlTests;

public class YamlModelGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedModelHasCorrectImports()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);

        models[0].RenderSource().Should().Contain("using System.Text.Json;");
        models[0].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[0].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[1].RenderSource().Should().Contain("using System.Text.Json;");
        models[1].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[1].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[2].RenderSource().Should().Contain("using System.Text.Json;");
        models[2].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[2].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[3].RenderSource().Should().Contain("using System.Text.Json;");
        models[3].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[3].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[4].RenderSource().Should().Contain("using System.Text.Json;");
        models[4].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[4].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[5].RenderSource().Should().Contain("using System.Text.Json;");
        models[5].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[5].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[6].RenderSource().Should().Contain("using System.Text.Json;");
        models[6].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[6].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[7].RenderSource().Should().Contain("using System.Text.Json;");
        models[7].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[7].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");

        models[8].RenderSource().Should().Contain("using System.Text.Json;");
        models[8].RenderSource().Should().Contain("using System.Runtime.Serialization;");
        models[8].RenderSource().Should().Contain("using System.ComponentModel.DataAnnotations;");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedModelHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);

        models[0].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[1].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[2].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[3].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[4].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[5].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[6].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[7].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        models[8].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedModelHasCorrectClassNameDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);
        models[0].ClassName.Should().Be("Customer");
        models[0].RenderSource().Should().Contain("public partial class Customer");

        models[1].ClassName.Should().Be("SavingsAccount");
        models[1].RenderSource().Should().Contain("public partial class SavingsAccount");

        models[2].ClassName.Should().Be("MortgageAccount");
        models[2].RenderSource().Should().Contain("public partial class MortgageAccount");

        models[3].ClassName.Should().Be("UpdateCustomerSavingsAccountDetailsRequest");
        models[3].RenderSource().Should().Contain("public partial class UpdateCustomerSavingsAccountDetailsRequest");

        models[4].ClassName.Should().Be("ProblemDetails");
        models[4].RenderSource().Should().Contain("public partial class ProblemDetails");

        models[5].ClassName.Should().Be("WebApiError");
        models[5].RenderSource().Should().Contain("public partial class WebApiError");

        models[6].ClassName.Should().Be("WebApiErrorDetails");
        models[6].RenderSource().Should().Contain("public partial class WebApiErrorDetails");

        models[7].ClassName.Should().Be("InterestDestination");
        models[7].RenderSource().Should().Contain("public partial class InterestDestination");

        models[8].ClassName.Should().Be("BankDetails");
        models[8].RenderSource().Should().Contain("public partial class BankDetails");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithInheritance_ThenGeneratedModelHasCorrectClassNameDefined()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Experience.JadeCore.Customers.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("SBS.WebAPI.Experience.JadeCore.Customers.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);
        models[0].ClassName.Should().Be("MarketingPreferences");
        models[0].RenderSource().Should().Contain("public partial class MarketingPreferences");

        models[1].ClassName.Should().Be("MarketingPreferencesGet");
        models[1].RenderSource().Should().Contain("public partial class MarketingPreferencesGet : MarketingPreferences");

        models[2].ClassName.Should().Be("MarketingPreferencesPatch");
        models[2].RenderSource().Should().Contain("public partial class MarketingPreferencesPatch : MarketingPreferences");

        models[3].ClassName.Should().Be("Customer");
        models[3].RenderSource().Should().Contain("public partial class Customer");

        models[4].ClassName.Should().Be("CustomerGet");
        models[4].RenderSource().Should().Contain("public partial class CustomerGet : Customer");

        models[5].ClassName.Should().Be("CustomerPatch");
        models[5].RenderSource().Should().Contain("public partial class CustomerPatch : Customer");

        models[6].ClassName.Should().Be("CustomerAddress");
        models[6].RenderSource().Should().Contain("public partial class CustomerAddress");

        models[7].ClassName.Should().Be("CustomerAddressGet");
        models[7].RenderSource().Should().Contain("public partial class CustomerAddressGet : CustomerAddress");

        models[8].ClassName.Should().Be("CustomerAddressPatch");
        models[8].RenderSource().Should().Contain("public partial class CustomerAddressPatch : CustomerAddress");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithInheritance_ThenGeneratedModelCorrectlyHidesBaseFunctions()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Experience.JadeCore.Customers.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("SBS.WebAPI.Experience.JadeCore.Customers.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);
        models[0].ClassName.Should().Be("MarketingPreferences");
        models[0].RenderSource().Should().Contain("public string ToJson()");
        models[0].RenderSource().Should().Contain("public JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[1].ClassName.Should().Be("MarketingPreferencesGet");
        models[1].RenderSource().Should().Contain("public new string ToJson()");
        models[1].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[2].ClassName.Should().Be("MarketingPreferencesPatch");
        models[2].RenderSource().Should().Contain("public new string ToJson()");
        models[2].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[3].ClassName.Should().Be("Customer");
        models[3].RenderSource().Should().Contain("public string ToJson()");
        models[3].RenderSource().Should().Contain("public JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[4].ClassName.Should().Be("CustomerGet");
        models[4].RenderSource().Should().Contain("public new string ToJson()");
        models[4].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[5].ClassName.Should().Be("CustomerPatch");
        models[5].RenderSource().Should().Contain("public new string ToJson()");
        models[5].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[6].ClassName.Should().Be("CustomerAddress");
        models[6].RenderSource().Should().Contain("public string ToJson()");
        models[6].RenderSource().Should().Contain("public JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[7].ClassName.Should().Be("CustomerAddressGet");
        models[7].RenderSource().Should().Contain("public new string ToJson()");
        models[7].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");

        models[8].ClassName.Should().Be("CustomerAddressPatch");
        models[8].RenderSource().Should().Contain("public new string ToJson()");
        models[8].RenderSource().Should().Contain("public new JsonObject ToJsonObjectWithNoUndefinedProperties()");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedModelHasCorrectAttributesDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(9);
        models[0].ClassName.Should().Be("Customer");
        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"customerNumber\")]");
        models[0].RenderSource().Should().Contain("public int CustomerNumber");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"firstName\")]");
        models[0].RenderSource().Should().Contain("[StringLength(15, MinimumLength=0)]");
        models[0].RenderSource().Should().Contain("public string FirstName");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"birthDate\")]");
        models[0].RenderSource().Should().Contain("public DateOnly BirthDate");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFileBasedModelHasCorrectAttributesDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Fax.Files.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(2);
        models[0].ClassName.Should().Be("FaxFileCall");
        models[1].ClassName.Should().Be("FaxFileResponse");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"filename\")]");
        models[0].RenderSource().Should().Contain("public string Filename { get; set; }");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"fileType\")]");
        models[0].RenderSource().Should().Contain("public string FileType { get; set; }");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"fileBinary\")]");
        models[0].RenderSource().Should().Contain("public byte[] FileBinary { get; set; }");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFileBasedFaxModelHasCorrectAttributesDefined()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Telephony.Fax.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models.Count.Should().Be(3);
        models[0].ClassName.Should().Be("Fax");
        models[1].ClassName.Should().Be("FaxTransmission");
        models[2].ClassName.Should().Be("ProblemDetails");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"fromNumber\")]");
        models[0].RenderSource().Should().Contain("public string FromNumber { get; set; }");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"toNumber\")]");
        models[0].RenderSource().Should().Contain("public string ToNumber { get; set; }");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"contactName\")]");
        models[0].RenderSource().Should().Contain("public string ContactName { get; set; }");

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"base64EncodedFile\")]");
        models[0].RenderSource().Should().Contain("public string Base64EncodedFile { get; set; }");

        models[1].RenderSource().Should().Contain("[JsonPropertyName(\"conversationId\")]");
        models[1].RenderSource().Should().Contain("public long ConversationId { get; set; }");

        models[1].RenderSource().Should().Contain("[JsonPropertyName(\"dateCreated\")]");
        models[1].RenderSource().Should().Contain("public DateTime DateCreated { get; set; }");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithFieldTypeOfNone_ThenGeneratedFileBasedModelObjectFieldIsInstantiated()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Domain.MortgageAccounts.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"securityAddress\")]");
        models[0].RenderSource().Should().Contain("public SecurityAddress SecurityAddress { get; set; } = new SecurityAddress();");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithFieldTypeOfArray_ThenGeneratedFileBasedModelObjectFieldIsInstantiatedAsList()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Domain.MortgageAccounts.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"accounts\")]");
        models[0].RenderSource().Should().Contain("public IList<MortgageAccountDetail> Accounts { get; set; } = new List<MortgageAccountDetail>();");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithFieldTypeOfNullableObjectArray_ThenGeneratedFileBasedModelObjectFieldIsNullable()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Domain.MortgageAccounts.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"nullableAccounts\")]");
        models[0].RenderSource().Should().Contain("public IList<MortgageAccountDetail>? NullableAccounts { get; set; }");
    }


    [Fact]
    public async void GivenYamlFileIsParsed_WithFieldTypeOfNullableStringArray_ThenGeneratedFileBasedModelObjectFieldIsNullable()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.Domain.MortgageAccounts.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[0].RenderSource().Should().Contain("[JsonPropertyName(\"nullableAccountList\")]");
        models[0].RenderSource().Should().Contain("public IList<string>? NullableAccountList { get; set; }");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithFieldTypeOfArray_ThenGeneratedFileBasedModelObjectFieldIsNullable()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("Software.WebAPI.SkiptonOnline.Experience.api.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = true,
            ClientTypes = true,
            Controllers = true,
            ResponseClasses = true,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[7].RenderSource().Should().Contain("public BankDetails? PayExternalBankAccount { get; set; }");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithRegexAttribute_ThenGeneratedFileBasedModelObjectFieldContainsRegularExpression_WithRegexMessage()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.SkiptonOnline.Experience.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("SBS.WebAPI.SkiptonOnline.Experience.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = false,
            ClientTypes = false,
            Controllers = false,
            ResponseClasses = false,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[3].RenderSource().Should().Contain("[RegularExpression(@\"^\\d{2}-\\d{2}-\\d{2}$\", ErrorMessage = \"targetNominatedAccountSortCode must match format 70-03-25\")]");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_WithRegexAttribute_ThenGeneratedFileBasedModelObjectFieldContainsRegularExpression_WithGenericMessage()
    {
        //// arrange
        var filename = "./Resources/SBS.WebAPI.SkiptonOnline.Experience.yaml";
        var contents = await File.ReadAllTextAsync(filename);
        var contractSettings = new ContractSettings("SBS.WebAPI.SkiptonOnline.Experience.yaml", false, new ContractFilesToGenerate
        {
            Models = true,
            BehaviourInterfaces = false,
            ClientTypes = false,
            Controllers = false,
            ResponseClasses = false,
        });

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiModelClass> models = sourceFactory.GenerateModels(contractSettings);

        models[3].RenderSource().Should().Contain("[RegularExpression(@\"^\\d{2}-\\d{2}-\\d{2}$\", ErrorMessage = \"testTargetNominatedAccountSortCodeWithNoExample must match regex pattern defined in the contract.\")]");
    }
}