using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlTests;

public class YamlControllerGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerHasCorrectImports()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(7);

        controllers[0].RenderSource().Should().Contain("using System.Threading.Tasks;");
        controllers[0].RenderSource().Should().Contain("using Microsoft.AspNetCore.Mvc;");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(7);

        controllers[0].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[1].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[2].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[3].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[4].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[5].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        controllers[6].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerHasCorrectClassName()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(7);

        controllers[0].RenderSource().Should().Contain("public sealed class DashboardForCustomerController : ControllerBase");
        controllers[1].RenderSource().Should().Contain("public sealed class AccountController : ControllerBase");
        controllers[2].RenderSource().Should().Contain("public sealed class profile_customerNumberController : ControllerBase");
        controllers[3].RenderSource().Should().Contain("public sealed class SavingsAccountDetailsController : ControllerBase");
        controllers[4].RenderSource().Should().Contain("public sealed class InterestDestinationController : ControllerBase");
        controllers[5].RenderSource().Should().Contain("public sealed class InterestDestinationCreateController : ControllerBase");
        controllers[6].RenderSource().Should().Contain("public sealed class NominatedAccountsDeleteController : ControllerBase");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerHasCorrectBehaviourAttribute()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(7);

        controllers[0].RenderSource().Should().Contain("private readonly IDashboardForCustomerControllerBehaviour _behaviour;");
        controllers[1].RenderSource().Should().Contain("private readonly IAccountControllerBehaviour _behaviour;");
        controllers[2].RenderSource().Should().Contain("private readonly Iprofile_customerNumberControllerBehaviour _behaviour;");
        controllers[3].RenderSource().Should().Contain("private readonly ISavingsAccountDetailsControllerBehaviour");
        controllers[4].RenderSource().Should().Contain("private readonly IInterestDestinationControllerBehaviour");
        controllers[5].RenderSource().Should().Contain("private readonly IInterestDestinationCreateControllerBehaviour");
        controllers[6].RenderSource().Should().Contain("private readonly INominatedAccountsDeleteControllerBehaviour");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerHasCorrectOperationFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(7);

        controllers[0].RenderSource().Should().Contain("[HttpGet]");
        controllers[0].RenderSource().Should().Contain("[Route(\"/dashboard/{customerNumber}\")]");
        controllers[0].RenderSource().Should().Contain("public async Task<IActionResult> GetDashboardForCustomer(long customerNumber)");

        controllers[1].RenderSource().Should().Contain("[HttpGet]");
        controllers[1].RenderSource().Should().Contain("[Route(\"/account/{accountNumber}\")]");
        controllers[1].RenderSource().Should().Contain("public async Task<IActionResult> GetAccount(long accountNumber)");

        controllers[2].RenderSource().Should().Contain("[HttpGet]");
        controllers[2].RenderSource().Should().Contain("[Route(\"/profile/{customerNumber}\")]");
        controllers[2].RenderSource().Should().Contain("public async Task<IActionResult> GetProfile(long customerNumber, string source, string source2)");

        controllers[3].RenderSource().Should().Contain("[HttpPatch]");
        controllers[3].RenderSource().Should().Contain("[Route(\"/accounts/{customerNumber}/savings/{accountNumber}/details\")]");
        controllers[3].RenderSource().Should().Contain("public async Task<IActionResult> UpdateCustomerSavingsAccountDetails(string customerNumber, int accountNumber, [FromHeader(Name = \"authorization\")] string authorization, [FromHeader(Name = \"api-key\")] string apiKey, [FromHeader(Name = \"version\")] string version, [FromHeader(Name = \"system-id\")] string systemId, [FromHeader(Name = \"session-id\")] string sessionId, [FromHeader(Name = \"message-id\")] string messageId, [FromHeader(Name = \"ip-address\")] string ipAddress, [FromBody] UpdateCustomerSavingsAccountDetailsRequest body)");

        controllers[4].RenderSource().Should().Contain("[HttpPost]");
        controllers[4].RenderSource().Should().Contain("[Route(\"/accounts/{customerNumber}/savings/{accountNumber}/interest-destination\")]");
        controllers[4].RenderSource().Should().Contain("public async Task<IActionResult> ChangeSavingsInterestDestination(string customerNumber, string accountNumber, [FromHeader(Name = \"authorization\")] string authorization, [FromHeader(Name = \"api-key\")] string apiKey, [FromHeader(Name = \"version\")] string version, [FromHeader(Name = \"system-id\")] string systemId, [FromHeader(Name = \"session-id\")] string sessionId, [FromHeader(Name = \"message-id\")] string messageId, [FromHeader(Name = \"ip-address\")] string ipAddress, [FromBody] InterestDestination body)");

        controllers[5].RenderSource().Should().Contain("[HttpPut]");
        controllers[5].RenderSource().Should().Contain("[Route(\"/accounts/{customerNumber}/savings/{accountNumber}/create-interest-destination\")]");
        controllers[5].RenderSource().Should().Contain("public async Task<IActionResult> CreateSavingsInterestDestination(string customerNumber, string accountNumber, [FromHeader(Name = \"authorization\")] string authorization, [FromHeader(Name = \"api-key\")] string apiKey, [FromHeader(Name = \"version\")] string version, [FromHeader(Name = \"system-id\")] string systemId, [FromHeader(Name = \"session-id\")] string sessionId, [FromHeader(Name = \"message-id\")] string messageId, [FromHeader(Name = \"ip-address\")] string ipAddress, [FromBody] InterestDestination body)");

        controllers[6].RenderSource().Should().Contain("[HttpDelete]");
        controllers[6].RenderSource().Should().Contain("[Route(\"/accounts/{customerNumber}/savings/{accountNumber}/nominated-accounts/{nominatedAccountId}\")]");
        controllers[6].RenderSource().Should().Contain("public async Task<IActionResult> DeleteSavingsNominatedAccount(string customerNumber, int accountNumber, int nominatedAccountId, [FromHeader(Name = \"authorization\")] string authorization, [FromHeader(Name = \"api-key\")] string apiKey, [FromHeader(Name = \"version\")] string version, [FromHeader(Name = \"system-id\")] string systemId, [FromHeader(Name = \"session-id\")] string sessionId, [FromHeader(Name = \"message-id\")] string messageId, [FromHeader(Name = \"ip-address\")] string ipAddress)");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedControllerWithFilesHasCorrectParametersToFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Fax.Files.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(1);

        controllers[0].RenderSource().Should().Contain("public async Task<IActionResult> FileUpload([FromBody] FaxFileCall body)");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFaxControllerWithFilesHasCorrectParametersToFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Telephony.Fax.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiControllerClass> controllers = sourceFactory.GenerateControllers();

        controllers.Count.Should().Be(1);

        controllers[0].RenderSource().Should().Contain("public async Task<IActionResult> SendFax([FromHeader(Name = \"api-key\")] string apiKey, [FromHeader(Name = \"version\")] string version, [FromHeader(Name = \"system-id\")] string systemId, [FromHeader(Name = \"session-id\")] string sessionId, [FromHeader(Name = \"message-id\")] string messageId, [FromBody] Fax body)");
    }
}
