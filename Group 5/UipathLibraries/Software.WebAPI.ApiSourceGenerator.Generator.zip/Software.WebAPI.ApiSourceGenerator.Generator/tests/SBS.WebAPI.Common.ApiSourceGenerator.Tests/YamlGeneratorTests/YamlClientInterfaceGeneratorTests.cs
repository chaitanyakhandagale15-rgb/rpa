using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Classes;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests.YamlGeneratorTests;

public class YamlClientInterfaceGeneratorTests
{
    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientInterfaceHasCorrectNamespace()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientInterface> clientInterfaces = sourceFactory.GenerateClientInterface();

        clientInterfaces.Count.Should().Be(7);

        clientInterfaces[0].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        clientInterfaces[1].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
        clientInterfaces[2].RenderSource().Should().Contain("namespace Software.WebAPI.SkiptonOnline.Experience");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientInterfaceHasCorrectClassName()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientInterface> clientInterfaces = sourceFactory.GenerateClientInterface();

        clientInterfaces.Count.Should().Be(7);

        clientInterfaces[0].RenderSource().Should().Contain("public interface IDashboardForCustomerClient");
        clientInterfaces[1].RenderSource().Should().Contain("public interface IAccountClient");
        clientInterfaces[2].RenderSource().Should().Contain("public interface Iprofile_customerNumberClient");
        clientInterfaces[3].RenderSource().Should().Contain("public interface ISavingsAccountDetailsClient");
        clientInterfaces[4].RenderSource().Should().Contain("public interface IInterestDestinationClient");
        clientInterfaces[5].RenderSource().Should().Contain("public interface IInterestDestinationCreateClient");
        clientInterfaces[6].RenderSource().Should().Contain("public interface INominatedAccountsDeleteClient");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedClientInterfaceHasCorrectOperationFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.SkiptonOnline.Experience.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientInterface> clientInterfaces = sourceFactory.GenerateClientInterface();

        clientInterfaces.Count.Should().Be(7);

        clientInterfaces[0].RenderSource().Should().Contain("public Task<HttpResponseMessage> GetDashboardForCustomer(long customerNumber);");
        clientInterfaces[1].RenderSource().Should().Contain("public Task<HttpResponseMessage> GetAccount(long accountNumber);");
        clientInterfaces[2].RenderSource().Should().Contain("public Task<HttpResponseMessage> get_profile_customerNumber(long customerNumber, string source, string source2);");
        clientInterfaces[3].RenderSource().Should().Contain("public Task<HttpResponseMessage> UpdateCustomerSavingsAccountDetails(string customerNumber, int accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, UpdateCustomerSavingsAccountDetailsRequest body)");
        clientInterfaces[4].RenderSource().Should().Contain("public Task<HttpResponseMessage> ChangeSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        clientInterfaces[5].RenderSource().Should().Contain("public Task<HttpResponseMessage> CreateSavingsInterestDestination(string customerNumber, string accountNumber, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress, InterestDestination body)");
        clientInterfaces[6].RenderSource().Should().Contain("public Task<HttpResponseMessage> DeleteSavingsNominatedAccount(string customerNumber, int accountNumber, int nominatedAccountId, string authorization, string apiKey, string version, string systemId, string sessionId, string messageId, string ipAddress)");
    }

    [Fact]
    public async void GivenYamlFileIsParsed_ThenGeneratedFaxClientInterfaceHasCorrectOperationFunction()
    {
        //// arrange
        var filename = "./Resources/Software.WebAPI.Telephony.Fax.api.yaml";
        var contents = await File.ReadAllTextAsync(filename);

        //// act
        OpenApiSourceFactory sourceFactory = new(contents);

        //// assert
        IList<OpenApiClientInterface> clientInterfaces = sourceFactory.GenerateClientInterface();

        clientInterfaces.Count.Should().Be(1);

        var source = clientInterfaces[0].RenderSource();

        clientInterfaces[0].RenderSource().Should().Contain("public Task<HttpResponseMessage> SendFax(string apiKey, string version, string systemId, string sessionId, string messageId, Fax body);");
    }

}
