using FluentAssertions;
using SBS.WebAPI.Common.ApiSourceGenerator.Generators.Helpers;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests;

public class CleanOffsetTests
{
    [Theory]
    [InlineData("/dashboard/{customerNumber}", "dashboard_customerNumber")]
    [InlineData("/profile/{customerNumber}", "profile_customerNumber")]
    public void TestCleanParameterName_WorksAsExpected(string offset, string expectedResult)
    {
        string result = OffsetHelpers.CleanOffset(offset);
        result.Should().Be(expectedResult);
    }
}