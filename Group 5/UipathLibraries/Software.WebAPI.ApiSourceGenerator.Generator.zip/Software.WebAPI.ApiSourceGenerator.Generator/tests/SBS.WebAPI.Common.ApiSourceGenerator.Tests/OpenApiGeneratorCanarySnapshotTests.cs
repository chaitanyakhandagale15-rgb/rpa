﻿using Microsoft.CodeAnalysis;
using FluentAssertions;

namespace SBS.WebAPI.Common.ApiSourceGenerator.Tests
{
    [UsesVerify]
    public class OpenApiGeneratorCanarySnapshotTests
    {
        private readonly SnapshotHelper snapshotHelper;

        public OpenApiGeneratorCanarySnapshotTests()
        {
            snapshotHelper = new SnapshotHelper();
        }

        [Fact]
        public Task GeneratorCalled_CanaryFile_NoErrors()
        {
            List<AdditionalText> additionalTexts = new()
            {
                new CustomAdditionalText(@"./Resources/Canary.txt")
            };

            var driver = snapshotHelper.GeneratorDriver(additionalTexts);

            var results = driver.GetRunResult().Results.Single();

            results.Diagnostics.Should().BeEmpty();

            return Verify(results.GeneratedSources);
        }
    }
}
